# Regras de estudo compartilhadas

Fonte extraída de `studify-app/src/lib/study-data.ts` e `priority-engine.ts`, preservando as regras existentes. O mobile consome este pacote e a integração Web substitui os arquivos antigos por reexports do mesmo pacote compilado. Nenhum backend novo.

`npm run build --prefix packages/study-core` compila JavaScript e declarações. O JavaScript permite que os testes Node da Web executem o pacote sem tentar remover tipos em node_modules.

O pacote distribuído para a Web fica em `integrations/web/vendor`. Atualizar a versão e gerar novamente o pacote após mudanças nas regras; executar testes nos dois clientes. Não modificar a cópia compilada nem criar outro motor no mobile.
